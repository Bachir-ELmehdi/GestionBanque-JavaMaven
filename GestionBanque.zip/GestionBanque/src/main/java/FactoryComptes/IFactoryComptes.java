package FactoryComptes;

import Projet.Entite.*;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Mehdi_bachir
 * Package =====> FactoryComptes
 * Date    =====> 26 oct. 2019 
 */
public interface IFactoryComptes {
    CompteCourant createCompteCourant( long num, double solde ,Client client);
    CompteEpargne createCompteEpargne( long num, double  solde, Client client, double mont,CompteCourant compteC );
}
