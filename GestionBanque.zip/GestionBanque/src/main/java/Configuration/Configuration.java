package Configuration;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Mehdi_bachir
 * Package =====> Configuration
 * Date    =====> 26 oct. 2019 
 */
public interface Configuration {
int max_Compte = 5;
int Compte = 1;
}
