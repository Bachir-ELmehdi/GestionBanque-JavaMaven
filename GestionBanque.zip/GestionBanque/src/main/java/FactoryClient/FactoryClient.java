package FactoryClient;

import Projet.Entite.Client;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Mehdi_bachir
 * Package =====> FactoryClient
 * Date    =====> 26 oct. 2019 
 */
public class FactoryClient implements IFactoryClient  {

	public Client creatClient(long num, String name) {
		// TODO Auto-generated method stub
	return new Client(num,name);
	}

}
