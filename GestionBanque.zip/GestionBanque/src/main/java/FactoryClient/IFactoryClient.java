package FactoryClient;

import Projet.Entite.Client;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Mehdi_bachir
 * Package =====> FactoryClient
 * Date    =====> 26 oct. 2019 
 */
public interface IFactoryClient {
	Client creatClient(long num, String name);

}
