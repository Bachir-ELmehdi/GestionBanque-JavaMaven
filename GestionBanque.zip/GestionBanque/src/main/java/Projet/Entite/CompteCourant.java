package Projet.Entite;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Mehdi_bachir
 * Package =====> Projet.Entite
 * Date    =====> 26 oct. 2019 
 */
public class CompteCourant  extends DecoratorCompte{
	
	/**
	 * 
	 */
	
	
	/**
	 * @param compteBasic
	 */
	public CompteCourant(CompteBasic compteBasic) {
		// TODO Auto-generated constructor stub
		super(compteBasic);
	}

	@Override
	
	public Client  getClient() {
		return this.getClient();
	}
	
	@Override
	public long getNumero()
	{
		return this.getNumero();
	}

	@Override
	public String toString() {
		return super.toString();
	}
	
	
}
