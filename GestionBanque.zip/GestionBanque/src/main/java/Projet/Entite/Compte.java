package Projet.Entite;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Mehdi_bachir
 * Package =====> Projet.Entite
 * Date    =====> 26 oct. 2019 
 */
public interface Compte {
	Client getClient();
//	double getSolde();
	long getNumero();
	String getNom();
    void setClient(Client cli);
	void setNumero(long num);
	String toString();
	double getSolde();
	void setSolde(double solde);
	boolean ExisteCompte();
	/**
	 * @return
	 */

}
